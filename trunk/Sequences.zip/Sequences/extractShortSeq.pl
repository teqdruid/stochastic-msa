use strict;
use warnings;

opendir(SEQDIR, "C:\\Users\\Siddhartha\\Desktop\\Computational Genomics\\Sequences");

my @sequenceFiles = readdir(SEQDIR);
splice(@sequenceFiles, 0, 3);
splice(@sequenceFiles, 20, 21);
my $fileCount = 1;
foreach my $sequenceFile (@sequenceFiles)
{
	open(SEQFILE, $sequenceFile);
	$/ = undef;
	my $sequence = <SEQFILE>;
	close(SEQFILE);
	open(SHORTSEQ, ">ShortSequences\\sequence".$fileCount);
	$sequence = substr($sequence, 0, 2000);
	$sequence =~ s/\s//;
	$sequence =~ s/.+?(sequence|assembly)//g;
	$sequence =~ s/\n//;
	print $sequence."\n";
	print SHORTSEQ $sequence;
	$fileCount++;
	close(SHORTSEQ);
	print $sequenceFile."\n";
}